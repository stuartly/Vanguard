Joern Nodes
===========

.. note:: Just a domain test.


Abstract syntax tree nodes
--------------------------

.. default-domain:: joern

.. node:: Function

        :param name: The name of the function.
