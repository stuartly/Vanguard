#!/usr/bin/env python2
# Run sanity checks against test database

import unittest
from tests import *

if __name__ == '__main__':
    unittest.main()
    
