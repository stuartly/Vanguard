
from lookupTests import *
from compositionTests import *
from udgTests import *
from dataFlowTests import *
from cfgTests import *
from parsingTests import *
from interproc import *
from initGraphTests import *
